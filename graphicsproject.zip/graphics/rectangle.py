def area(length,breadth):
    return length * breadth
def perimeter(length,breadth):
    return 2*(length + breadth)