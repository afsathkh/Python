def surface_area(length,breadth,height):
    return 2*(length*breadth+breadth*height+length*height)
def volume(length,breadth,height):
    return length*breadth*height