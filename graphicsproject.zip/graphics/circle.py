import math
def area(radius):
    return math.pi *radius *radius
def circumference(radius):
    return 2 *math.pi * radius